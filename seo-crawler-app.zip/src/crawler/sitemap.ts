import axios from "axios";
import { XMLParser } from "fast-xml-parser";

export interface RobotsInfo {
  disallowedPaths: string[];
  sitemapUrls: string[];
}

export async function fetchRobotsTxt(baseUrl: string, userAgent = "*"): Promise<RobotsInfo> {
  const result: RobotsInfo = {
    disallowedPaths: [],
    sitemapUrls: []
  };

  try {
    const parsedBase = new URL(baseUrl);
    const robotsUrl = `${parsedBase.protocol}//${parsedBase.host}/robots.txt`;
    const res = await axios.get(robotsUrl, {
      timeout: 8000,
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" },
      validateStatus: () => true
    });

    if (res.status !== 200 || typeof res.data !== "string") {
      return result;
    }

    const lines = res.data.split(/\r?\n/);
    let currentUserAgent = "";

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line || line.startsWith("#")) continue;

      const [directive, ...rest] = line.split(":");
      const key = directive.trim().toLowerCase();
      const val = rest.join(":").trim();

      if (key === "user-agent") {
        currentUserAgent = val.toLowerCase();
      } else if (key === "disallow") {
        if (currentUserAgent === "*" || currentUserAgent === userAgent.toLowerCase()) {
          if (val) {
            result.disallowedPaths.push(val);
          }
        }
      } else if (key === "sitemap") {
        if (val) {
          result.sitemapUrls.push(val);
        }
      }
    }
  } catch (err) {
    // Ignore robots.txt errors
  }

  return result;
}

export async function fetchSitemapUrls(sitemapUrl: string, maxUrls = 10000, visitedSitemaps = new Set<string>()): Promise<string[]> {
  const collectedUrls: string[] = [];
  if (visitedSitemaps.has(sitemapUrl) || visitedSitemaps.size > 50) {
    return collectedUrls;
  }
  visitedSitemaps.add(sitemapUrl);

  try {
    const res = await axios.get(sitemapUrl, {
      timeout: 25000,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/xml,text/xml,*/*;q=0.9"
      },
      responseType: "text"
    });

    if (res.status !== 200 || !res.data) {
      return collectedUrls;
    }

    const parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: "@_"
    });

    const parsed = parser.parse(res.data);

    // Case 1: Sitemap Index (<sitemapindex><sitemap><loc>...</loc></sitemap></sitemapindex>)
    if (parsed.sitemapindex && parsed.sitemapindex.sitemap) {
      const sitemaps = Array.isArray(parsed.sitemapindex.sitemap)
        ? parsed.sitemapindex.sitemap
        : [parsed.sitemapindex.sitemap];

      const subLocs: string[] = sitemaps
        .map((sm: any) => (typeof sm.loc === "string" ? sm.loc.trim() : ""))
        .filter((loc: string) => Boolean(loc));

      // Fetch all sub-sitemaps in parallel with Promise.allSettled for maximum speed and fault tolerance
      const results = await Promise.allSettled(
        subLocs.map(subLoc => fetchSitemapUrls(subLoc, maxUrls, visitedSitemaps))
      );

      for (const r of results) {
        if (r.status === "fulfilled") {
          for (const u of r.value) {
            if (!collectedUrls.includes(u)) {
              collectedUrls.push(u);
              if (collectedUrls.length >= maxUrls) break;
            }
          }
        }
        if (collectedUrls.length >= maxUrls) break;
      }
    }

    // Case 2: Urlset (<urlset><url><loc>...</loc></url></urlset>)
    if (parsed.urlset && parsed.urlset.url) {
      const urls = Array.isArray(parsed.urlset.url) ? parsed.urlset.url : [parsed.urlset.url];
      for (const u of urls) {
        if (collectedUrls.length >= maxUrls) break;
        const loc = typeof u.loc === "string" ? u.loc.trim() : "";
        if (loc && !collectedUrls.includes(loc)) {
          collectedUrls.push(loc);
        }
      }
    }
  } catch (err) {
    // Sitemap fetch error ignored
  }

  return collectedUrls;
}

export async function discoverSitemapUrls(baseUrl: string, maxUrls = 10000): Promise<string[]> {
  const robots = await fetchRobotsTxt(baseUrl);
  const potentialSitemaps = [...robots.sitemapUrls];

  const parsedBase = new URL(baseUrl);
  const hostBase = `${parsedBase.protocol}//${parsedBase.host}`;

  const standardCandidates = [
    `${hostBase}/sitemap.xml`,
    `${hostBase}/sitemap_index.xml`,
    `${hostBase}/wp-sitemap.xml`,
    `${hostBase}/sitemap-posts.xml`
  ];

  for (const c of standardCandidates) {
    if (!potentialSitemaps.includes(c)) {
      potentialSitemaps.push(c);
    }
  }

  const allDiscovered: string[] = [];
  for (const sitemapUrl of potentialSitemaps) {
    const urls = await fetchSitemapUrls(sitemapUrl, maxUrls);
    for (const u of urls) {
      if (!allDiscovered.includes(u)) {
        allDiscovered.push(u);
        if (allDiscovered.length >= maxUrls) break;
      }
    }
    if (allDiscovered.length > 0) {
      return allDiscovered;
    }
  }

  return [];
}
